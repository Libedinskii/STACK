package ru.libedinskiy.exception;

public class InvalidOperationStackException extends RuntimeException {
}
